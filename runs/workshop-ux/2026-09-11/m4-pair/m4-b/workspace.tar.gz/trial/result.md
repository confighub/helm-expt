# GPU workload versus supplied Node facts

## Outcome

The supplied KServe InferenceService requires 2 GPUs per replica and the `nvidia.com/gpu.product=NVIDIA-H100-SXM4-80GB` selector.

- **Candidate**: candidate.json (`./trial/candidate.json` in workspace archive), exit 0. The supplied node has the required label and allocatable GPU count (`2`), so the input snapshot qualifies as a candidate.
- **Mismatch**: mismatch.json (`./trial/mismatch.json` in workspace archive), exit 1. The copied node has the right label but only `1` allocatable GPU; this establishes an insufficient per-node GPU mismatch.
- **Unknown**: unknown.json (`./trial/unknown.json` in workspace archive), exit 3. The copied node retains the matching label but omits allocatable GPU data; this establishes that missing GPU facts prevent a conclusion.

These results help decide whether supplied facts are sufficient for static target qualification: matching facts produce a candidate, insufficient facts produce mismatch, and absent required facts remain unknown. The next action for a real target is to supply an authorized, current Node snapshot, review omitted checks, and qualify the exact workload before deployment.

## Proven, unknown, and not run

Proven by these local receipts: parsing of the retained KServe workload and Node snapshot, selector comparison, per-node GPU count comparison, stable status and exit-code behavior, and input SHA-256 retention. The target was not contacted (`liveChecked: false`) and execution is `not-run`.

Unknown or outside scope: snapshot authenticity/freshness, free GPU capacity, GPU memory/partitioning, runtime compatibility, other resources, affinity, taints, readiness, quotas, scheduling, replicas/autoscaling, serving controllers/API availability, credentials, model entitlement, and application or inference response. The candidate is not deployment readiness or inference proof.

## Friction

The README and task instructions clearly specified the three cases and exit codes. Each deliberate nonzero case must be run independently so shell chaining does not hide the receipt. Existing output files refuse overwrite, so distinct output names are needed.
