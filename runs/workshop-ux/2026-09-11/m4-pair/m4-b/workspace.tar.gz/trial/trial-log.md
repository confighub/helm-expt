# Trial log

Trial root: `./trial`.

Inputs were copied from the pinned plugin checkout; no original plugin input was edited. Setup was supplied and excluded. Every cub command used the required `CUB_CONFIG=./cli/config.yaml` prefix.

## Commands and retained outputs

1. Candidate command is retained in candidate.command.txt (`./trial/candidate.command.txt` in workspace archive); exit code is candidate.exit-code.txt (`./trial/candidate.exit-code.txt` in workspace archive); JSON is candidate.json (`./trial/candidate.json` in workspace archive); stdout/stderr are `candidate.stdout.log` and `candidate.stderr.log`.
2. Mismatch command is retained in mismatch.command.txt (`./trial/mismatch.command.txt` in workspace archive); exit code is mismatch.exit-code.txt (`./trial/mismatch.exit-code.txt` in workspace archive); JSON is mismatch.json (`./trial/mismatch.json` in workspace archive); stdout/stderr are `mismatch.stdout.log` and `mismatch.stderr.log`.
3. Unknown command is retained in unknown.command.txt (`./trial/unknown.command.txt` in workspace archive); exit code is unknown.exit-code.txt (`./trial/unknown.exit-code.txt` in workspace archive); JSON is unknown.json (`./trial/unknown.json` in workspace archive); stdout/stderr are `unknown.stdout.log` and `unknown.stderr.log`.

Copied inputs: model.yaml (`./trial/model.yaml` in workspace archive), nodes.yaml (`./trial/nodes.yaml` in workspace archive), mismatch-nodes.yaml (`./trial/mismatch-nodes.yaml` in workspace archive), and unknown-nodes.yaml (`./trial/unknown-nodes.yaml` in workspace archive).

No login, cluster, ConfigHub, registry, publishing, credentials, or network target was used. The local instruction page was fetched from `http://127.0.0.1:8767/site/index.html`; plugin README and task examples were consulted.
